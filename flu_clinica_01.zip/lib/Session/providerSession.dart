// ignore: file_names
import 'package:flu_clinica_01/Session/data.dart';
import 'package:flutter/foundation.dart';

class UserProvider with ChangeNotifier {
  UserData? _userData;

  UserData? get userData => _userData;

  void setUser(UserData userData) {
    _userData = userData;
    notifyListeners();
  }

  void clearUser() {
    _userData = null;
    notifyListeners();
  }

  void updateUserData({
    required String name,
    required String telefono,
    required String genero,
    required DateTime fechaNacimiento,
  }) {
    if (_userData != null) {
      // Actualizar los campos de _userData con los nuevos valores
      _userData!.name = name;
      _userData!.phoneNumber = telefono;
      _userData!.gender = genero;
      _userData!.birthDate = fechaNacimiento;

      // Notificar a los listeners (por ejemplo, Widgets que están escuchando cambios)
      notifyListeners();
    } else {
      throw Exception('User data is not set');
    }
  }
}
