class UserData {
  late String id;
  late String email;
  late String name;
  late String role;
  late String? idGoogle;
  late DateTime? birthDate;
  late String? gender;
  late String? phoneNumber;
  late String? photoUrl;
  late String? createdAt;
  late String? updatedAt;

  UserData(
      {required this.role,
      this.idGoogle,
      this.birthDate,
      this.gender,
      this.phoneNumber,
      this.photoUrl,
      this.createdAt,
      this.updatedAt,
      required this.id,
      required this.email,
      required this.name});
}

/*
"id": 1,
  "nombre": "Johan",
  "correo": "johan@gmail.com",
  "rol": "paciente",
  "id_google": null,
  "fecha_nacimiento": null,
  "genero": null,
  "telefono": null,
  "foto_perfil": null,
  "created_at": null,
  "updated_at": null


  */