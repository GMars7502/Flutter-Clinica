class IpAddress {
  final String _domain = '<--INSERTA DOMINIO API -->';

  String get domain => _domain;
}

