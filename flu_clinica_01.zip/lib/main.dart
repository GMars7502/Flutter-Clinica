import 'package:flutter/material.dart';
import 'package:flu_clinica_01/pages/Home_page.dart';
import 'package:flu_clinica_01/pages/Login.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'package:flu_clinica_01/pages/registre.dart';
import 'package:provider/provider.dart';
import 'package:flu_clinica_01/Session/providerSession.dart';
import 'package:flu_clinica_01/pages/page_admin.dart';
import 'package:flu_clinica_01/pages/page_medico.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => UserProvider()),
        // Otros proveedores según sea necesario
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Clinica',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: LoginPage.routename,
      // Cambia a la ruta de inicio de sesión
      routes: {
        LoginPage.routename: (context) => const LoginPage(),
        HomePage.routename: (context) => const HomePage(),
        RegistroPage.routename: (context) => const RegistroPage(),
        HomeAdmin.routename: (context) => const HomeAdmin(),
        PagMedico.routename: (context) => const PagMedico(),
        // Otras rutas según sea necesario
      },
    );
  }
}
