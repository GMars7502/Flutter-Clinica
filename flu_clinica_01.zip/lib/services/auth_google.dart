import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

class AuthGoogle {
  Future<User?> loginGoogle() async {
    try {
      await GoogleSignIn().signOut();
      final GoogleSignInAccount? accountGoogle = await GoogleSignIn().signIn();
      if (accountGoogle != null) {
        final GoogleSignInAuthentication googleAuth =
            await accountGoogle.authentication;

        final OAuthCredential credential = GoogleAuthProvider.credential(
          accessToken: googleAuth.accessToken,
          idToken: googleAuth.idToken,
        );

        final UserCredential userCredential =
            await FirebaseAuth.instance.signInWithCredential(credential);

        // Obtener el usuario autenticado
        final User? user = userCredential.user;
        // Imprimir información en la consola para verificar

        return user;
      } else {
        print('Inicio de sesión con Google cancelado.');
        return null;
      }
    } catch (e) {
      print('Error al iniciar sesión con Google: $e');
      return null;
    }
  }
}
