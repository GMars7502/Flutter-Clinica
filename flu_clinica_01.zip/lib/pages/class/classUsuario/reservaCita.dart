import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:flu_clinica_01/address/ipaddress.dart';
//import 'package:flu_clinica_01/session/providerSession.dart';
import 'package:flu_clinica_01/Session/providerSession.dart';

class ReservaCitasPage extends StatefulWidget {
  final String title;

  const ReservaCitasPage({super.key, required this.title});

  @override
  _ReservaCitasPageState createState() => _ReservaCitasPageState();
}

class _ReservaCitasPageState extends State<ReservaCitasPage> {
  List<dynamic> especialidades = [];
  String? selectedEspecialidad;
  List<Map<String, dynamic>> medicos = [];
  Map<String, dynamic>? selectedMedico;
  DateTime? selectedDate;
  TimeOfDay? selectedTime;
  final TextEditingController _motivoController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _fetchEspecialidades();
  }

  Future<void> _fetchEspecialidades() async {
    try {
      IpAddress direccion = IpAddress();
      String domain = direccion.domain;
      String path = '/api/especialidades';

      final response = await http.get(Uri.http(domain, path));

      if (response.statusCode == 200) {
        final List<dynamic> especialidadesList = json.decode(response.body);
        setState(() {
          especialidades = especialidadesList;
        });
      } else {
        _showSnackBar('No hay especialidades disponibles');
      }
    } catch (error) {
      _showSnackBar('Error al cargar las especialidades');
    }
  }

  Future<void> _fetchMedicos(String especialidadId) async {
    try {
      IpAddress direccion = IpAddress();
      String domain = direccion.domain;
      String path = '/api/usuarios';

      final response = await http.get(Uri.http(domain, path));

      if (response.statusCode == 200) {
        final List<dynamic> usuariosList = json.decode(response.body);
        final List<Map<String, dynamic>> filteredMedicos = usuariosList
            .where((usuario) =>
                usuario['rol'] == 'medico' &&
                usuario['medico'] != null &&
                usuario['medico']['id_especialidad'].toString() ==
                    especialidadId)
            .toList()
            .cast<Map<String, dynamic>>();

        setState(() {
          medicos = filteredMedicos;
        });
      } else {
        _showSnackBar('No hay médicos disponibles para esta especialidad');
      }
    } catch (error) {
      _showSnackBar('Error al cargar los médicos');
    }
  }

  Future<void> _crearCita(BuildContext context) async {
    if (selectedMedico == null ||
        selectedDate == null ||
        selectedTime == null ||
        _motivoController.text.isEmpty) {
      _showSnackBar('Por favor complete todos los campos');
      return;
    }

    final userProvider = Provider.of<UserProvider>(context, listen: false);
    final user = userProvider.userData;

    if (user == null) {
      _showSnackBar('No se pudo obtener la información del usuario');
      return;
    }

    final DateTime fechaHora = DateTime(
      selectedDate!.year,
      selectedDate!.month,
      selectedDate!.day,
      selectedTime!.hour,
      selectedTime!.minute,
    );

    if (fechaHora.weekday == DateTime.sunday) {
      _showSnackBar('No se pueden hacer citas los domingos');
      return;
    }

    if (fechaHora.hour < 8 || fechaHora.hour >= 21) {
      _showSnackBar('La hora de la cita debe estar entre 8 AM y 9 PM');
      return;
    }

    if (DateTime.now().hour > fechaHora.hour) {
      _showSnackBar('La hora de la cita debe ser posible');
      return;
    }

    try {
      IpAddress direccion = IpAddress();
      String domain = direccion.domain;
      String path = '/api/citas';

      Map<String, dynamic> body = {
        'id_paciente': user.id.toString(),
        'id_medico': selectedMedico!['medico']['id'].toString(),
        'fecha_hora': DateFormat('yyyy-MM-dd HH:mm:ss').format(fechaHora),
        'estado': 'programada',
        'motivo_consulta': _motivoController.text,
      };

      var response = await http.post(
        Uri.http(domain, path),
        body: jsonEncode(body),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode >= 200 && response.statusCode < 300) {
        _showSnackBar('Cita reservada con éxito');
        // Aquí puedes agregar lógica para navegar o limpiar el formulario
      } else {
        _showSnackBar('Error al reservar la cita');
      }
    } catch (e) {
      _showSnackBar('Error al crear la cita: $e');
    }
  }

  void _showSnackBar(String message) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message)),
      );
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
      });
    }
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null && picked != selectedTime) {
      setState(() {
        selectedTime = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          DropdownButtonFormField<String>(
            value: selectedEspecialidad,
            decoration: const InputDecoration(
              labelText: 'Especialidad',
            ),
            items: especialidades.map((especialidad) {
              return DropdownMenuItem<String>(
                value: especialidad['id'].toString(),
                child: Text(especialidad['nombre']),
              );
            }).toList(),
            onChanged: (String? value) {
              if (value != null) {
                setState(() {
                  selectedEspecialidad = value;
                  selectedMedico = null;
                });
                _fetchMedicos(value);
              }
            },
          ),
          const SizedBox(height: 12.0),
          DropdownButtonFormField<Map<String, dynamic>>(
            value: selectedMedico,
            decoration: const InputDecoration(
              labelText: 'Médico',
            ),
            items: medicos.map((medico) {
              return DropdownMenuItem<Map<String, dynamic>>(
                value: medico,
                child: Text(medico['nombre']),
              );
            }).toList(),
            onChanged: (Map<String, dynamic>? value) {
              setState(() {
                selectedMedico = value;
              });
            },
          ),
          const SizedBox(height: 12.0),
          TextButton(
            onPressed: () => _selectDate(context),
            child: Text(
              'Fecha: ${selectedDate != null ? DateFormat('dd/MM/yyyy').format(selectedDate!) : 'No seleccionada'}',
            ),
          ),
          const SizedBox(height: 12.0),
          TextButton(
            onPressed: () => _selectTime(context),
            child: Text(
              'Hora: ${selectedTime != null ? selectedTime!.format(context) : 'No seleccionada'}',
            ),
          ),
          const SizedBox(height: 12.0),
          TextFormField(
            controller: _motivoController,
            decoration: const InputDecoration(
              labelText: 'Motivo de la consulta',
            ),
          ),
          const SizedBox(height: 20.0),
          ElevatedButton(
            onPressed: () async {
              await _crearCita(context);
            },
            child: const Text('Reservar Cita'),
          ),
        ],
      ),
    );
  }
}
