import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import '../../../Session/providerSession.dart';
import 'package:flu_clinica_01/address/ipaddress.dart';

class CitasProgramadasPage extends StatefulWidget {
  final String title;
  const CitasProgramadasPage({super.key, required this.title});

  @override
  _CitasProgramadasPageState createState() => _CitasProgramadasPageState();
}

class _CitasProgramadasPageState extends State<CitasProgramadasPage> {
  List<dynamic> citas = [];
  List<dynamic> citasFiltradas = [];
  final TextEditingController _nombreController = TextEditingController();
  final TextEditingController _diaController = TextEditingController();
  final TextEditingController _mesController = TextEditingController();
  final TextEditingController _anioController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _fetchCitas();
  }

  Future<void> _fetchCitas() async {
    final userProvider = Provider.of<UserProvider>(context, listen: false);
    final user = userProvider.userData;
    final usuarioId = user?.id;

    if (usuarioId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No se pudo obtener el ID del médico')),
      );
      return;
    }
    try {
      //String domain = 'matasanos.c1.is';
      //String path00 = '/api/usuarios/$usuarioId';
      IpAddress direccion = IpAddress();
      String domain = direccion.domain;
      String path0 = '/api/usuarios/$usuarioId';
      //String Urlst = 'http://169.254.140.204:8000/api/usuarios/$usuarioId';
      final tresponse = await http.get(
        Uri.http(domain, path0),
      );
      var jsonResponse = jsonDecode(tresponse.body);
      String idMedico = jsonResponse['medico']['id'].toString();

      String path1 = '/api/citas/citasmedico/$idMedico';

      //String Urlstd =
      //  'http://169.254.140.204:8000/api/citas/citasmedico/$idMedico';

      final response = await http.get(
        Uri.http(domain, path1),
      );

      if (response.statusCode == 200) {
        final List<dynamic> allCitas = json.decode(response.body);
        setState(() {
          citas =
              allCitas.where((cita) => cita['estado'] == 'programada').toList();
          citasFiltradas = List.from(citas);
        });
      } else {
        print(response.statusCode);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
                content:
                    Text('Error al obtener citas: ${response.statusCode}')),
          );
        }
      }
    } catch (e) {
      print(e);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }
  }

  void _filterCitas() {
    setState(() {
      citasFiltradas = citas.where((cita) {
        final nombrePaciente = cita['paciente']['nombre'].toLowerCase();
        final fechaProgramada = DateTime.parse(cita['fecha_hora']);

        bool cumpleFiltroNombre = _nombreController.text.isEmpty ||
            nombrePaciente.contains(_nombreController.text.toLowerCase());

        bool cumpleFiltroDia = _diaController.text.isEmpty ||
            fechaProgramada.day.toString() == _diaController.text;

        bool cumpleFiltromes = _mesController.text.isEmpty ||
            fechaProgramada.month.toString() == _mesController.text;

        bool cumpleFiltroAnio = _anioController.text.isEmpty ||
            fechaProgramada.year.toString() == _anioController.text;

        return cumpleFiltroNombre &&
            cumpleFiltroDia &&
            cumpleFiltromes &&
            cumpleFiltroAnio;
      }).toList();
    });
  }

  void _navigateToCompletacionCita(dynamic cita) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CompletacionCitaPage(cita: cita),
      ),
    ).then((_) => _fetchCitas());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _nombreController,
                    decoration: const InputDecoration(
                      labelText: 'Nombre',
                      prefixIcon: Icon(Icons.search),
                    ),
                    onChanged: (_) => _filterCitas(),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _diaController,
                    decoration: const InputDecoration(
                      labelText: 'Día',
                      prefixIcon: Icon(Icons.calendar_today),
                    ),
                    keyboardType: TextInputType.number,
                    onChanged: (_) => _filterCitas(),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _mesController,
                    decoration: const InputDecoration(
                      labelText: 'Mes',
                      prefixIcon: Icon(Icons.calendar_today),
                    ),
                    keyboardType: TextInputType.number,
                    onChanged: (_) => _filterCitas(),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _anioController,
                    decoration: const InputDecoration(
                      labelText: 'Año',
                      prefixIcon: Icon(Icons.calendar_today),
                    ),
                    keyboardType: TextInputType.number,
                    onChanged: (_) => _filterCitas(),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: citasFiltradas.length,
              itemBuilder: (context, index) {
                final cita = citasFiltradas[index];
                return Card(
                  margin:
                      const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                  child: ListTile(
                    title: Text(cita['paciente']['nombre']),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                            'Fecha: ${DateFormat('dd-MM-yyyy').format(DateTime.parse(cita['fecha_hora']))}'),
                        Text('Descripción: ${cita['motivo_consulta']}'),
                      ],
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.edit),
                      onPressed: () => _navigateToCompletacionCita(cita),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class CompletacionCitaPage extends StatefulWidget {
  final dynamic cita;

  const CompletacionCitaPage({super.key, required this.cita});

  @override
  _CompletacionCitaPageState createState() => _CompletacionCitaPageState();
}

class _CompletacionCitaPageState extends State<CompletacionCitaPage> {
  String _estado = 'programada';
  final TextEditingController _diagnosticoController = TextEditingController();
  final TextEditingController _tratamientoController = TextEditingController();
  final TextEditingController _observacionesController =
      TextEditingController();
  final TextEditingController _medicamentosController = TextEditingController();
  final TextEditingController _dosisController = TextEditingController();
  final TextEditingController _indicacionesController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Completación de Cita'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            DropdownButtonFormField<String>(
              value: _estado,
              decoration: const InputDecoration(labelText: 'ESTADO'),
              items: ['programada', 'completada', 'cancelada']
                  .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                  .toList(),
              onChanged: (value) {
                setState(() {
                  _estado = value!;
                });
              },
            ),
            const TextField(
              decoration: InputDecoration(
                labelText: 'MOTIVO',
                hintText: 'no se puede editar',
              ),
              enabled: false,
            ),
            if (_estado == 'completada') ...[
              const Text('Nota médica',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              TextField(
                controller: _diagnosticoController,
                decoration: const InputDecoration(labelText: 'DIAGNÓSTICO'),
                maxLines: 3,
              ),
              TextField(
                controller: _tratamientoController,
                decoration: const InputDecoration(labelText: 'TRATAMIENTO'),
                maxLines: 3,
              ),
              TextField(
                controller: _observacionesController,
                decoration: const InputDecoration(labelText: 'OBSERVACIONES'),
                maxLines: 3,
              ),
              const SizedBox(height: 16),
              const Text('Receta',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              TextField(
                controller: _medicamentosController,
                decoration: const InputDecoration(labelText: 'MEDICAMENTOS'),
              ),
              TextField(
                controller: _dosisController,
                decoration: const InputDecoration(labelText: 'DOSIS'),
              ),
              TextField(
                controller: _indicacionesController,
                decoration: const InputDecoration(labelText: 'INDICACIONES'),
              ),
            ],
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.grey),
                  child: const Text('Cancelar'),
                ),
                ElevatedButton(
                  onPressed: _guardarCambios,
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
                  child: const Text('Guardar'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _guardarCambios() async {
    // Implementar la lógica para guardar los cambios
    // Usar las API proporcionadas para actualizar la cita, crear nota médica y receta
    // Ejemplo:
    try {
      /* http://matasanos.c1.is/api
                       String domain = 'matasanos.c1.is';
                        String path = '/api/usuarios';

                        var tresponse = await http.post(
                          Uri.http(domain, path),
                          body: jsonEncode(body),
                          headers: {'Content-Type': 'application/json'},
                        );

      
      */
      IpAddress direccion = IpAddress();
      String domain = direccion.domain;
      // Actualizar cita
      //String URL = 'http://169.254.140.204:8000/api/citas/${widget.cita['id']}';
      //String domain = 'matasanos.c1.is';
      String path = '/api/citas/${widget.cita['id']}';
      await http.put(
        Uri.http(domain, path),
        body: json.encode({
          'estado': _estado,
          // Otros campos si es necesario
        }),
        headers: {'Content-Type': 'application/json'},
      );

      if (_estado == 'completada') {
        // Crear nota médica
        String path1 = '/api/notas-medicas/';
        await http.post(
          Uri.http(domain, path1),
          body: json.encode({
            'id_cita': widget.cita['id'],
            'diagnostico': _diagnosticoController.text,
            'tratamiento': _tratamientoController.text,
            'observaciones': _observacionesController.text,
            'fecha_creacion': DateTime.now().toIso8601String(),
          }),
          headers: {'Content-Type': 'application/json'},
        );

        // Crear receta
        String path2 = '/api/recetas/';
        await http.post(
          Uri.http(domain, path2),
          body: json.encode({
            'id_cita': widget.cita['id'],
            'medicamento': _medicamentosController.text,
            'dosis': _dosisController.text,
            'instrucciones':
                _indicacionesController.text, // Ajusta según sea necesario
          }),
          headers: {'Content-Type': 'application/json'},
        );
      }
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Cambios guardados con éxito')),
        );
      }
      Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al guardar los cambios: $e')),
        );
      }
    }
  }
}
