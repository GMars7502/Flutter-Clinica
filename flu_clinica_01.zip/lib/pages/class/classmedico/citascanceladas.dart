import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import '../../../Session/providerSession.dart';
import 'package:flu_clinica_01/address/ipaddress.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

class CitasCanceladasPage extends StatefulWidget {
  final String title;
  const CitasCanceladasPage({super.key, required this.title});

  @override
  _CitasCanceladasPage createState() => _CitasCanceladasPage();
}

class _CitasCanceladasPage extends State<CitasCanceladasPage> {
  List<dynamic> citas = [];
  List<dynamic> citasFiltradas = [];
  final TextEditingController _nombreController = TextEditingController();
  final TextEditingController _diaController = TextEditingController();
  final TextEditingController _mesController = TextEditingController();
  final TextEditingController _anioController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _fetchCitas();
  }

  Future<void> _fetchCitas() async {
    final userProvider = Provider.of<UserProvider>(context, listen: false);
    final user = userProvider.userData;
    final usuarioId = user?.id;

    if (usuarioId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No se pudo obtener el ID del médico')),
      );
      return;
    }
    try {
      IpAddress direccion = IpAddress();
      String domain = direccion.domain;
      String path0 = '/api/usuarios/$usuarioId';

      final tresponse = await http.get(
        Uri.http(domain, path0),
      );
      var jsonResponse = jsonDecode(tresponse.body);
      String idMedico = jsonResponse['medico']['id'].toString();

      String path1 = '/api/citas/citasmedico/$idMedico';

      final response = await http.get(
        Uri.http(domain, path1),
      );

      if (response.statusCode == 200) {
        final List<dynamic> allCitas = json.decode(response.body);
        setState(() {
          citas =
              allCitas.where((cita) => cita['estado'] == 'cancelada').toList();
          citasFiltradas = List.from(citas);
        });
      } else {
        print(response.statusCode);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
                content:
                    Text('Error al obtener citas: ${response.statusCode}')),
          );
        }
      }
    } catch (e) {
      print(e);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }
  }

  void _filterCitas() {
    setState(() {
      citasFiltradas = citas.where((cita) {
        final nombrePaciente = cita['paciente']['nombre'].toLowerCase();
        final fechaProgramada = DateTime.parse(cita['fecha_hora']);

        bool cumpleFiltroNombre = _nombreController.text.isEmpty ||
            nombrePaciente.contains(_nombreController.text.toLowerCase());

        bool cumpleFiltroDia = _diaController.text.isEmpty ||
            fechaProgramada.day.toString() == _diaController.text;

        bool cumpleFiltromes = _mesController.text.isEmpty ||
            fechaProgramada.month.toString() == _mesController.text;

        bool cumpleFiltroAnio = _anioController.text.isEmpty ||
            fechaProgramada.year.toString() == _anioController.text;

        return cumpleFiltroNombre &&
            cumpleFiltroDia &&
            cumpleFiltromes &&
            cumpleFiltroAnio;
      }).toList();
    });
  }

  void _navigateToDetalleCita(dynamic cita) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => DetalleCitaPage(cita: cita),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _nombreController,
                    decoration: const InputDecoration(
                      labelText: 'Nombre',
                      prefixIcon: Icon(Icons.search),
                    ),
                    onChanged: (_) => _filterCitas(),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _diaController,
                    decoration: const InputDecoration(
                      labelText: 'Día',
                      prefixIcon: Icon(Icons.calendar_today),
                    ),
                    keyboardType: TextInputType.number,
                    onChanged: (_) => _filterCitas(),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _mesController,
                    decoration: const InputDecoration(
                      labelText: 'Mes',
                      prefixIcon: Icon(Icons.calendar_today),
                    ),
                    keyboardType: TextInputType.number,
                    onChanged: (_) => _filterCitas(),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _anioController,
                    decoration: const InputDecoration(
                      labelText: 'Año',
                      prefixIcon: Icon(Icons.calendar_today),
                    ),
                    keyboardType: TextInputType.number,
                    onChanged: (_) => _filterCitas(),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: citasFiltradas.length,
              itemBuilder: (context, index) {
                final cita = citasFiltradas[index];
                return Card(
                  margin:
                      const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                  child: ListTile(
                    title: Text(cita['paciente']['nombre']),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                            'Fecha: ${DateFormat('dd-MM-yyyy').format(DateTime.parse(cita['fecha_hora']))}'),
                        Text('Descripción: ${cita['motivo_consulta']}'),
                      ],
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.visibility),
                      onPressed: () => _navigateToDetalleCita(cita),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class DetalleCitaPage extends StatelessWidget {
  final dynamic cita;

  const DetalleCitaPage({super.key, required this.cita});

  Future<dynamic> _obtenerCita(BuildContext context) async {
    final idCita = cita['id'];
    IpAddress direccion = IpAddress();
    String domain = direccion.domain;
    String path0 = '/api/citas/$idCita';

    final tresponse = await http.get(
      Uri.http(domain, path0),
    );
    var jsonResponse = jsonDecode(tresponse.body);

    return jsonResponse;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detalle de Cita Completada'),
      ),
      body: FutureBuilder<dynamic>(
        future: _obtenerCita(context),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (!snapshot.hasData) {
            return const Center(child: Text('No hay datos disponibles.'));
          }

          final respond = snapshot.data;
          final notaMedica = respond['nota_medica'];
          final recetas = respond['recetas'];

          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Paciente: ${cita['paciente']['nombre']}',
                    style: Theme.of(context).textTheme.titleLarge),
                Text(
                    'Fecha: ${DateFormat('dd-MM-yyyy').format(DateTime.parse(cita['fecha_hora']))}'),
                Text('Estado: ${cita['estado']}'),
                Text('Motivo: ${cita['motivo_consulta']}'),
                const SizedBox(height: 16),
                const Text('Nota médica',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                Text(
                    'Diagnóstico: ${notaMedica != null ? notaMedica['diagnostico'] : 'No disponible'}'),
                Text(
                    'Tratamiento: ${notaMedica != null ? notaMedica['tratamiento'] : 'No disponible'}'),
                Text(
                    'Observaciones: ${notaMedica != null ? notaMedica['observaciones'] : 'No disponible'}'),
                const SizedBox(height: 16),
                const Text('Receta',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                if (recetas != null && recetas.isNotEmpty)
                  ...recetas.map<Widget>((receta) {
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Medicamento: ${receta['medicamento']}'),
                        Text('Dosis: ${receta['dosis']}'),
                        Text('Instrucciones: ${receta['instrucciones']}'),
                        const SizedBox(height: 8),
                      ],
                    );
                  }).toList()
                else
                  const Text('No disponible'),
                const SizedBox(height: 24),
                Center(
                  child: ElevatedButton(
                    onPressed: () => _generarPDF(context),
                    child: const Text('Generar PDF'),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Future<void> _generarPDF(BuildContext context) async {
    final pdf = pw.Document();
    final notaMedica = cita['nota_medica'];
    final recetas = cita['recetas'];

    pdf.addPage(
      pw.Page(
        build: (pw.Context context) {
          return pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text('Detalle de Cita Médica',
                  style: pw.TextStyle(
                      fontSize: 20, fontWeight: pw.FontWeight.bold)),
              pw.SizedBox(height: 20),
              pw.Text('Paciente: ${cita['paciente']['nombre']}'),
              pw.Text(
                  'Fecha: ${DateFormat('dd-MM-yyyy').format(DateTime.parse(cita['fecha_hora']))}'),
              pw.Text('Estado: ${cita['estado']}'),
              pw.Text('Motivo: ${cita['motivo_consulta']}'),
              pw.SizedBox(height: 10),
              pw.Text('Nota médica',
                  style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
              pw.Text(
                  'Diagnóstico: ${notaMedica != null ? notaMedica['diagnostico'] : 'No disponible'}'),
              pw.Text(
                  'Tratamiento: ${notaMedica != null ? notaMedica['tratamiento'] : 'No disponible'}'),
              pw.Text(
                  'Observaciones: ${notaMedica != null ? notaMedica['observaciones'] : 'No disponible'}'),
              pw.SizedBox(height: 10),
              pw.Text('Receta',
                  style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
              if (recetas != null && recetas.isNotEmpty)
                ...recetas.map<pw.Widget>((receta) {
                  return pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      pw.Text('Medicamento: ${receta['medicamento']}'),
                      pw.Text('Dosis: ${receta['dosis']}'),
                      pw.Text('Instrucciones: ${receta['instrucciones']}'),
                      pw.SizedBox(height: 8),
                    ],
                  );
                }).toList()
              else
                pw.Text('No disponible'),
            ],
          );
        },
      ),
    );

    await Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdf.save(),
    );
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('PDF generado correctamente')),
      );
    }
  }
}
