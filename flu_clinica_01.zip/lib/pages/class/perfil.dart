import 'dart:convert';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flu_clinica_01/pages/Login.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:http/http.dart' as http;
import '../../Session/providerSession.dart';
import 'package:flu_clinica_01/address/ipaddress.dart';

class pagPerfil extends StatefulWidget {
  final String title;
  const pagPerfil({super.key, required this.title});

  @override
  _pagPerfilState createState() => _pagPerfilState();
}

class _pagPerfilState extends State<pagPerfil> {
  late TextEditingController _nombreController;
  late TextEditingController _telefonoController;
  late String _selectedGenero;
  late DateTime _selectedFechaNacimiento;

  @override
  void initState() {
    super.initState();
    final userProvider = Provider.of<UserProvider>(context, listen: false);
    final user = userProvider.userData;

    // Inicializar los controladores con los datos actuales del usuario
    _nombreController = TextEditingController(text: user?.name ?? '');
    _telefonoController = TextEditingController(text: user?.phoneNumber ?? '');
    _selectedGenero =
        user?.gender ?? 'masculino'; // Valor por defecto o el que ya tenga
    _selectedFechaNacimiento = user?.birthDate ?? DateTime.now();
  }

  @override
  void dispose() {
    _nombreController.dispose();
    _telefonoController.dispose();
    super.dispose();
  }

  void _actualizarPerfil() async {
    final userProvider = Provider.of<UserProvider>(context, listen: false);
    final user = userProvider.userData;

    String fechaNacimiento =
        DateFormat('yyyy-MM-dd').format(_selectedFechaNacimiento);

    if (_nombreController.text.length < 2) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('El nombre debe tener al menos 2 caracteres'),
        ),
      );
      return;
    }

    if (_telefonoController.text.length < 10) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('El número de teléfono debe tener al menos 10 dígitos'),
        ),
      );
      return;
    }

    try {
      IpAddress direccion = IpAddress();
      String domain = direccion.domain;
      String path0 = '/api/usuarios/${user?.id}';
      //String otraUrl = 'http://169.254.140.204:8000/api/usuarios/${user?.id}';
      Map<String, String> body = {
        'nombre': _nombreController.text,
        'genero': _selectedGenero,
        'fecha_nacimiento': fechaNacimiento,
        'telefono': _telefonoController.text,
      };

      var tresponse = await http.put(
        Uri.http(domain, path0),
        body: jsonEncode(body),
        headers: {'Content-Type': 'application/json'},
      );

      if (tresponse.statusCode >= 200 && tresponse.statusCode < 300) {
        userProvider.updateUserData(
          name: _nombreController.text,
          telefono: _telefonoController.text,
          genero: _selectedGenero,
          fechaNacimiento: _selectedFechaNacimiento,
        );

        // Mostrar mensaje o realizar acciones adicionales si es necesario
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Perfil actualizado correctamente'),
            ),
          );
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('El perfil no se pudo actualiza'),
          ),
        );
      }
    } catch (e) {
      print(e);
      if (context.mounted) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(e.toString()),
            ),
          );
        }
      }
    }

    // Formatear la fecha de nacimiento seleccionada para enviarla al servidor si es necesario
    //DateTime fechaNacimiento = DateFormat('yyyy-MM-dd').parse();

    // Actualización local de los datos del usuario en el provider
  }

  void _eliminarCuenta() async {
    final userProvider = Provider.of<UserProvider>(context, listen: false);
    final user = userProvider.userData;

    try {
      await FirebaseAuth.instance.currentUser?.delete();
      IpAddress direccion = IpAddress();
      String domain = direccion.domain;
      String path0 = '/api/usuarios/${user?.id}';

      //String otraUrl = 'http://169.254.140.204:8000/api/usuarios/${user?.id}';

      var tresponse = await http.delete(
        Uri.http(domain, path0),
        headers: {'Content-Type': 'application/json'},
      );

      if (tresponse.statusCode >= 200 && tresponse.statusCode < 300) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('El usuario se elimino correctamente'),
            ),
          );

          final userProvider =
              Provider.of<UserProvider>(context, listen: false);
          userProvider.clearUser(); // Limpiar datos de usuario localmente
          Navigator.pushNamedAndRemoveUntil(
              context, LoginPage.routename, (route) => false);
        }
        // Aquí podrías implementar la lógica para eliminar la cuenta del usuario
        // por ejemplo, enviar una solicitud HTTP para eliminar la cuenta en el servidor
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('El usuario no se pudo eliminar'),
            ),
          );
        }
      }

      // Después de eliminar la cuenta, deberías navegar al inicio de sesión u otra página adecuada
    } catch (e) {
      print(e);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(e.toString()),
          ),
        );
      }
    }
  }

  Future<void> _selectFechaNacimiento(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedFechaNacimiento,
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() {
        _selectedFechaNacimiento = picked;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          Image.asset('assets/logo.jpeg'),
          const SizedBox(height: 20),
          Text(
            widget.title,
            style: const TextStyle(fontSize: 24),
          ),
          const SizedBox(height: 20),
          TextFormField(
            controller: _nombreController,
            decoration: const InputDecoration(
              labelText: 'Nombre',
            ),
          ),
          const SizedBox(height: 12.0),
          DropdownButtonFormField<String>(
            value: _selectedGenero,
            decoration: const InputDecoration(
              labelText: 'Género',
            ),
            items: ['masculino', 'femenino', 'otro'].map((String genero) {
              return DropdownMenuItem<String>(
                value: genero,
                child: Text(genero),
              );
            }).toList(),
            onChanged: (String? value) {
              if (value != null) {
                setState(() {
                  _selectedGenero = value;
                });
              }
            },
          ),
          const SizedBox(height: 12.0),
          Row(
            children: [
              TextButton(
                onPressed: () => _selectFechaNacimiento(context),
                child: Text(
                  'Fecha de Nacimiento: ${DateFormat('dd/MM/yyyy').format(_selectedFechaNacimiento)}',
                ),
              ),
            ],
          ),
          const SizedBox(height: 12.0),
          TextFormField(
            controller: _telefonoController,
            decoration: const InputDecoration(
              labelText: 'Teléfono',
            ),
            keyboardType: TextInputType.phone,
          ),
          const SizedBox(height: 20.0),
          ElevatedButton(
            onPressed: _actualizarPerfil,
            child: const Text('Actualizar Datos'),
          ),
          const SizedBox(height: 12.0),
          ElevatedButton(
            onPressed: _eliminarCuenta,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red, // background
            ),
            child: const Text('Eliminar Cuenta'),
          ),
        ],
      ),
    );
  }
}
