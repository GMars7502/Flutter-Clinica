import 'dart:convert';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:flu_clinica_01/address/ipaddress.dart';

class RegistroDoctorPage extends StatefulWidget {
  final String title;
  const RegistroDoctorPage({super.key, required this.title});

  @override
  _RegistroDoctorPageState createState() => _RegistroDoctorPageState();
}

class _RegistroDoctorPageState extends State<RegistroDoctorPage> {
  late TextEditingController nombreController;
  late TextEditingController correoController;
  late TextEditingController contrasenaController;
  late TextEditingController fechaNacimientoController;
  late String selectedGenero;
  String? selectedEspecialidad;
  late TextEditingController telefonoController;
  late TextEditingController licenciaController;
  List<dynamic> especialidades = [];

  @override
  void initState() {
    super.initState();
    _fetchEspecialidades();
    nombreController = TextEditingController();
    correoController = TextEditingController();
    contrasenaController = TextEditingController();
    fechaNacimientoController = TextEditingController();
    selectedGenero = 'masculino';
    telefonoController = TextEditingController();
    licenciaController = TextEditingController();
  }

  Future<void> _fetchEspecialidades() async {
    try {
      IpAddress direccion = IpAddress();
      String domain = direccion.domain;
      String path = '/api/especialidades';
      var response = await http.get(Uri.http(domain, path));

      if (response.statusCode == 200) {
        setState(() {
          especialidades = jsonDecode(response.body);
          if (especialidades.isNotEmpty) {
            selectedEspecialidad = especialidades[0]['id'].toString();
          }
        });
      } else {
        if (mounted) {
          showSnackBar(context, 'Error al obtener especialidades');
        }
      }
    } catch (e) {
      if (mounted) {
        showSnackBar(context, 'Error al obtener especialidades: $e');
      }
    }
  }

  Future<void> _registrarDoctor() async {
    String nombre = nombreController.text;
    String correo = correoController.text;
    String contrasena = contrasenaController.text;
    String fechaNacimiento = fechaNacimientoController.text;
    String telefono = telefonoController.text;
    String licencia = licenciaController.text;

    if (nombre.length < 2) {
      showSnackBar(context, 'El nombre debe tener al menos 2 caracteres');
      return;
    }
    if (contrasena.length <= 8) {
      showSnackBar(context, 'La contraseña debe tener al menos 8 caracteres');
      return;
    }
    if (telefono.length < 9) {
      showSnackBar(
          context, 'El número de teléfono debe tener al menos 9 caracteres');
      return;
    }
    if (correo.isEmpty ||
        contrasena.isEmpty ||
        telefono.isEmpty ||
        licencia.isEmpty ||
        selectedEspecialidad == null) {
      showSnackBar(context, 'Debe llenar todos los campos');
      return;
    }

    try {
      UserCredential userCredential =
          await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: correo,
        password: contrasena,
      );
      User? user = userCredential.user;
      String idgoogle = user!.uid;

      Map<String, dynamic> body = {
        'nombre': nombre,
        'correo': correo,
        'contraseña': contrasena,
        'rol': 'medico',
        'id_google': idgoogle,
        'fecha_nacimiento': fechaNacimiento,
        'genero': selectedGenero,
        'telefono': telefono,
        'id_especialidad': selectedEspecialidad,
        'numero_licencia': licencia,
      };

      IpAddress direccion = IpAddress();
      String domain = direccion.domain;
      String path = '/api/usuarios';

      var response = await http.post(
        Uri.http(domain, path),
        body: jsonEncode(body),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 201) {
        if (mounted) {
          showSnackBar(context, 'Doctor registrado correctamente');
        }
      } else {
        if (mounted) {
          showSnackBar(
              context, 'Error al registrar doctor: ${response.statusCode}');
        }
      }
    } on FirebaseAuthException catch (e) {
      if (mounted) {
        showSnackBar(context, 'Error en el registro: ${e.message}');
      }
    } catch (e) {
      if (mounted) {
        showSnackBar(context, 'Error en la solicitud HTTP: $e');
      }
    }
  }

  Future<void> _selectFechaNacimiento(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() {
        fechaNacimientoController.text =
            DateFormat('yyyy-MM-dd').format(picked);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                controller: nombreController,
                decoration: const InputDecoration(
                  labelText: 'Nombre',
                ),
              ),
              const SizedBox(height: 12.0),
              TextFormField(
                controller: correoController,
                decoration: const InputDecoration(
                  labelText: 'Correo',
                ),
              ),
              const SizedBox(height: 12.0),
              TextFormField(
                controller: contrasenaController,
                decoration: const InputDecoration(
                  labelText: 'Contraseña',
                ),
                obscureText: true,
              ),
              const SizedBox(height: 12.0),
              TextFormField(
                controller: fechaNacimientoController,
                decoration: InputDecoration(
                  labelText: 'Fecha de Nacimiento',
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.calendar_today),
                    onPressed: () => _selectFechaNacimiento(context),
                  ),
                ),
                readOnly: true,
              ),
              const SizedBox(height: 12.0),
              DropdownButtonFormField<String>(
                value: selectedGenero,
                decoration: const InputDecoration(
                  labelText: 'Género',
                ),
                items: ['masculino', 'femenino', 'otro'].map((String genero) {
                  return DropdownMenuItem<String>(
                    value: genero,
                    child: Text(genero),
                  );
                }).toList(),
                onChanged: (String? value) {
                  if (value != null) {
                    setState(() {
                      selectedGenero = value;
                    });
                  }
                },
              ),
              const SizedBox(height: 12.0),
              DropdownButtonFormField<String>(
                value: selectedEspecialidad,
                decoration: const InputDecoration(
                  labelText: 'Especialidad',
                ),
                items: especialidades
                    .map<DropdownMenuItem<String>>((especialidad) {
                  return DropdownMenuItem<String>(
                    value: especialidad['id'].toString(),
                    child: Text(especialidad['nombre']),
                  );
                }).toList(),
                onChanged: (String? value) {
                  if (value != null) {
                    setState(() {
                      selectedEspecialidad = value;
                    });
                  }
                },
              ),
              const SizedBox(height: 12.0),
              TextFormField(
                controller: telefonoController,
                decoration: const InputDecoration(
                  labelText: 'Teléfono',
                ),
                keyboardType: TextInputType.phone,
              ),
              const SizedBox(height: 12.0),
              TextFormField(
                controller: licenciaController,
                decoration: const InputDecoration(
                  labelText: 'Número de Licencia',
                ),
              ),
              const SizedBox(height: 20.0),
              ElevatedButton(
                onPressed: _registrarDoctor,
                child: const Text('Registrar'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void showSnackBar(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }
}
