import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:flu_clinica_01/address/ipaddress.dart';

// ignore: use_build_context_synchronously
class Cita {
  final int id;
  final int idPaciente;
  final int idMedico;
  final DateTime fechaHora;
  String estado;
  final String motivoConsulta;
  final String nombrePaciente;
  final String nombreMedico;

  Cita({
    required this.id,
    required this.idPaciente,
    required this.idMedico,
    required this.fechaHora,
    required this.estado,
    required this.motivoConsulta,
    required this.nombrePaciente,
    required this.nombreMedico,
  });

  factory Cita.fromJson(Map<String, dynamic> json) {
    return Cita(
      id: json['id'],
      idPaciente: json['id_paciente'],
      idMedico: json['id_medico'],
      fechaHora: DateTime.parse(json['fecha_hora']),
      estado: json['estado'],
      motivoConsulta: json['motivo_consulta'],
      nombrePaciente: json['paciente']['nombre'],
      nombreMedico: json['medico']['id']
          .toString(), // Asumiendo que el nombre del médico no está disponible directamente
    );
  }
}

class CitasPage extends StatefulWidget {
  final String title;

  const CitasPage({super.key, required this.title});

  @override
  _CitasPageState createState() => _CitasPageState();
}

class _CitasPageState extends State<CitasPage> {
  late Future<List<Cita>> _futureCitas;

  @override
  void initState() {
    super.initState();
    _futureCitas = fetchCitas();
  }

  Future<List<Cita>> fetchCitas() async {
    IpAddress direccion = IpAddress();
    String domain = direccion.domain;
    String path0 = '/api/citas/';
    final response = await http.get(Uri.http(domain, path0));
    if (response.statusCode == 200) {
      List jsonResponse = json.decode(response.body);
      return jsonResponse.map((item) => Cita.fromJson(item)).toList();
    } else {
      throw Exception('Failed to load citas');
    }
  }

  Future<void> updateCitaEstado(int id, String nuevoEstado) async {
    IpAddress direccion = IpAddress();
    String domain = direccion.domain;
    String path1 = '/api/citas/$id';
    final response = await http.put(
      Uri.http(domain, path1),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(<String, String>{
        'estado': nuevoEstado,
      }),
    );

    if (response.statusCode == 200) {
      setState(() {
        _futureCitas = fetchCitas();
      });
    } else {
      throw Exception('Failed to update cita');
    }
  }

  Future<void> deleteCita(int id) async {
    IpAddress direccion = IpAddress();
    String domain = direccion.domain;
    String path2 = '/api/citas/$id';
    final response = await http.delete(Uri.http(domain, path2));

    if (response.statusCode == 200) {
      setState(() {
        _futureCitas = fetchCitas();
      });
    } else {
      throw Exception('Failed to delete cita');
    }
  }

  Future<void> _generatePdf() async {
    final pdf = pw.Document();

    final citas = await _futureCitas;

    pdf.addPage(
      pw.Page(
        build: (context) => pw.Column(
          children: [
            pw.Text('Lista de Citas', style: const pw.TextStyle(fontSize: 24)),
            pw.SizedBox(height: 20),
            pw.TableHelper.fromTextArray(
              headers: ['Paciente', 'Fecha y Hora', 'Estado', 'Motivo'],
              data: citas.map((cita) {
                return [
                  cita.nombrePaciente,
                  cita.fechaHora.toString(),
                  cita.estado,
                  cita.motivoConsulta,
                ];
              }).toList(),
            ),
          ],
        ),
      ),
    );

    await Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdf.save(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        actions: [
          IconButton(
            icon: const Icon(Icons.picture_as_pdf),
            onPressed: _generatePdf,
          ),
        ],
      ),
      body: FutureBuilder<List<Cita>>(
        future: _futureCitas,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return ListView.builder(
              itemCount: snapshot.data!.length,
              itemBuilder: (context, index) {
                return Card(
                  child: ListTile(
                    title: Text(
                        'Paciente: ${snapshot.data![index].nombrePaciente}'),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                            'Fecha: ${snapshot.data![index].fechaHora.toString()}'),
                        Text('Estado: ${snapshot.data![index].estado}'),
                        Text('Motivo: ${snapshot.data![index].motivoConsulta}'),
                      ],
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        PopupMenuButton<String>(
                          onSelected: (String result) {
                            updateCitaEstado(snapshot.data![index].id, result);
                          },
                          itemBuilder: (BuildContext context) =>
                              <PopupMenuEntry<String>>[
                            const PopupMenuItem<String>(
                              value: 'programada',
                              child: Text('Programada'),
                            ),
                            const PopupMenuItem<String>(
                              value: 'completada',
                              child: Text('Completada'),
                            ),
                            const PopupMenuItem<String>(
                              value: 'cancelada',
                              child: Text('Cancelada'),
                            ),
                          ],
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete),
                          onPressed: () {
                            deleteCita(snapshot.data![index].id);
                          },
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          } else if (snapshot.hasError) {
            return Text("${snapshot.error}");
          }
          return const CircularProgressIndicator();
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const CrearCitaPage()),
          ).then((_) {
            setState(() {
              _futureCitas = fetchCitas();
            });
          });
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}

class CrearCitaPage extends StatefulWidget {
  const CrearCitaPage({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _CrearCitaPageState createState() => _CrearCitaPageState();
}

class _CrearCitaPageState extends State<CrearCitaPage> {
  final _formKey = GlobalKey<FormState>();
  String? _idPaciente;
  String? _idMedico;
  DateTime? _fechaHora;
  String? _estado;
  String? _motivoConsulta;

  Future<void> _crearCita() async {
    if (_formKey.currentState!.validate()) {
      IpAddress direccion = IpAddress();
      String domain = direccion.domain;
      String path2 = '/api/citas';
      final response = await http.post(
        Uri.http(domain, path2),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(<String, String>{
          'id_paciente': _idPaciente!,
          'id_medico': _idMedico!,
          'fecha_hora': _fechaHora!.toIso8601String(),
          'estado': _estado!,
          'motivo_consulta': _motivoConsulta!,
        }),
      );

      if (response.statusCode == 201) {
        if (mounted) {
          Navigator.pop(context);
        }
      } else {
        throw Exception('Failed to create cita');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Crear Cita'),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              decoration: const InputDecoration(labelText: 'ID Paciente'),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Por favor ingrese el ID del paciente';
                }
                return null;
              },
              onSaved: (value) {
                _idPaciente = value;
              },
            ),
            TextFormField(
              decoration: const InputDecoration(labelText: 'ID Médico'),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Por favor ingrese el ID del médico';
                }
                return null;
              },
              onSaved: (value) {
                _idMedico = value;
              },
            ),
            TextFormField(
              decoration: const InputDecoration(labelText: 'Fecha y Hora'),
              onTap: () async {
                DateTime? pickedDate = await showDatePicker(
                  context: context,
                  initialDate: DateTime.now(),
                  firstDate: DateTime.now(),
                  lastDate: DateTime(2025),
                );
                if (pickedDate != null) {
                  TimeOfDay? pickedTime = await showTimePicker(
                    context: context,
                    initialTime: TimeOfDay.now(),
                  );

                  if (pickedTime != null) {
                    setState(() {
                      _fechaHora = DateTime(
                        pickedDate.year,
                        pickedDate.month,
                        pickedDate.day,
                        pickedTime.hour,
                        pickedTime.minute,
                      );
                    });
                  }
                }
              },
              validator: (value) {
                if (_fechaHora == null) {
                  return 'Por favor seleccione la fecha y hora';
                }
                return null;
              },
            ),
            DropdownButtonFormField<String>(
              decoration: const InputDecoration(labelText: 'Estado'),
              items:
                  ['programada', 'completada', 'cancelada'].map((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
              onChanged: (String? newValue) {
                setState(() {
                  _estado = newValue;
                });
              },
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Por favor seleccione el estado';
                }
                return null;
              },
            ),
            TextFormField(
              decoration:
                  const InputDecoration(labelText: 'Motivo de Consulta'),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Por favor ingrese el motivo de consulta';
                }
                return null;
              },
              onSaved: (value) {
                _motivoConsulta = value;
              },
            ),
            ElevatedButton(
              onPressed: _crearCita,
              child: const Text('Crear Cita'),
            ),
          ],
        ),
      ),
    );
  }
}
