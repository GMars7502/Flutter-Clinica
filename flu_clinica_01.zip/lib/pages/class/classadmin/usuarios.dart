import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:flu_clinica_01/address/ipaddress.dart';

class User {
  final String id;
  final String nombre;
  final String correo;
  final String rol;
  final String? idGoogle;
  final String? fechaNacimiento;
  final String? genero;
  final String? telefono;
  final String? fotoPerfil;
  final String? createdAt;
  final String? updatedAt;
  final String? medico;

  User({
    required this.id,
    required this.nombre,
    required this.correo,
    required this.rol,
    this.idGoogle,
    this.fechaNacimiento,
    this.genero,
    this.telefono,
    this.fotoPerfil,
    this.createdAt,
    this.updatedAt,
    this.medico,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['id'].toString(),
      nombre: json['nombre'] ?? '',
      correo: json['correo'] ?? '',
      rol: json['rol'] ?? '',
      idGoogle: json['id_google']?.toString(),
      fechaNacimiento: json['fecha_nacimiento']?.toString(),
      genero: json['genero']?.toString(),
      telefono: json['telefono']?.toString(),
      fotoPerfil: json['foto_perfil']?.toString(),
      createdAt: json['created_at']?.toString(),
      updatedAt: json['updated_at']?.toString(),
      medico: json['medico']?.toString(),
    );
  }
}

Future<List<User>> fetchUsers() async {
  try {
    IpAddress direccion = IpAddress();
    String domain = direccion.domain;
    String path0 = '/api/usuarios/';

    final response = await http.get(Uri.http(domain, path0));
    print('Se recorrio el pedido api');

    if (response.statusCode >= 200 && response.statusCode < 300) {
      List<dynamic> jsonResponse = json.decode(response.body);
      print('Se recibieron los datos');
      return jsonResponse.map((data) => User.fromJson(data)).toList();
    } else {
      print('Error fetching users: ${response.statusCode} - ${response.body}');
      throw Exception('Failed to load users');
    }
  } catch (e) {
    print('Error fetching users: $e');
    return [];
  }
}

class AllUsuarios extends StatefulWidget {
  final String title;

  const AllUsuarios({super.key, required this.title});

  @override
  _AllUsuariosState createState() => _AllUsuariosState();
}

class _AllUsuariosState extends State<AllUsuarios> {
  late Future<List<User>> _futureUsers;
  final _searchController = TextEditingController();
  List<User> _users = [];
  List<User> _filteredUsers = [];
  User? _selectedUser;

  @override
  void initState() {
    super.initState();
    _futureUsers = fetchUsers();
  }

  void _filterUsers(String query) {
    setState(() {
      _filteredUsers = _users
          .where((user) =>
              user.nombre.toLowerCase().contains(query.toLowerCase()) ||
              user.correo.toLowerCase().contains(query.toLowerCase()))
          .toList();
    });
  }

  void _showUserDetails(User user) {
    setState(() {
      _selectedUser = user;
    });
  }

  void _cancelEdit() {
    setState(() {
      _selectedUser = null;
    });
  }

  void _deleteUser(String id) async {
    try {
      IpAddress direccion = IpAddress();
      String domain = direccion.domain;
      String path0 = '/api/usuarios/$id';

      final response = await http.delete(
        Uri.http(domain, path0),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Usuario eliminado correctamente')),
          );
        }
        setState(() {
          _futureUsers = fetchUsers();
          _selectedUser = null;
        });
      } else {
        throw Exception('Error al eliminar el usuario');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: ${e.toString()}')),
        );
      }
    }
  }

  Future<void> _generatePdf() async {
    final pdf = pw.Document();

    pdf.addPage(
      pw.Page(
        build: (context) => pw.Column(
          children: [
            pw.Text('Lista de Usuarios',
                style: const pw.TextStyle(fontSize: 24)),
            pw.SizedBox(height: 20),
            pw.TableHelper.fromTextArray(
              headers: ['Nombre', 'Correo', 'Rol'],
              data: _users
                  .map((user) => [user.nombre, user.correo, user.rol])
                  .toList(),
            ),
          ],
        ),
      ),
    );

    await Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async => pdf.save(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        actions: [
          IconButton(
            icon: const Icon(Icons.picture_as_pdf),
            onPressed: _generatePdf,
          ),
        ],
      ),
      body: _selectedUser == null
          ? _buildUserList()
          : _buildUserDetails(_selectedUser!),
    );
  }

  Widget _buildUserList() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: TextField(
            controller: _searchController,
            decoration: InputDecoration(
              labelText: 'Buscar usuarios',
              prefixIcon: const Icon(Icons.search),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            onChanged: _filterUsers,
          ),
        ),
        Expanded(
          child: FutureBuilder<List<User>>(
            future: _futureUsers,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              } else if (snapshot.hasError) {
                return Center(child: Text('Error: ${snapshot.error}'));
              } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                return const Center(child: Text('No se encontraron usuarios'));
              } else {
                _users = snapshot.data!;
                _filteredUsers =
                    _filteredUsers.isEmpty ? _users : _filteredUsers;
                final users =
                    _searchController.text.isEmpty ? _users : _filteredUsers;
                return ListView.builder(
                  itemCount: users.length,
                  itemBuilder: (context, index) {
                    final user = users[index];
                    return Card(
                      elevation: 2,
                      margin: const EdgeInsets.symmetric(
                        vertical: 8,
                        horizontal: 16,
                      ),
                      child: ListTile(
                        leading: CircleAvatar(
                          child: Text(user.nombre[0]),
                        ),
                        title: Text(user.nombre),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(user.correo),
                            Text(user.rol),
                          ],
                        ),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.edit),
                              onPressed: () => _showUserDetails(user),
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete),
                              onPressed: () => _deleteUser(user.id),
                            ),
                          ],
                        ),
                        onTap: () => _showUserDetails(user),
                      ),
                    );
                  },
                );
              }
            },
          ),
        ),
      ],
    );
  }

  Widget _buildUserDetails(User user) {
    final nombreController = TextEditingController(text: user.nombre);
    final telefonoController = TextEditingController(text: user.telefono ?? '');

    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Editar Usuario',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: nombreController,
            decoration: const InputDecoration(
              labelText: 'Nombre',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          TextFormField(
            controller: telefonoController,
            decoration: const InputDecoration(
              labelText: 'Teléfono',
              border: OutlineInputBorder(),
            ),
            keyboardType: TextInputType.phone,
          ),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              ElevatedButton(
                onPressed: () async {
                  try {
                    IpAddress direccion = IpAddress();
                    String domain = direccion.domain;
                    String path2 = '/api/usuarios/${user.id}';
                    final response = await http.put(
                      Uri.http(domain, path2),
                      headers: {'Content-Type': 'application/json'},
                      body: jsonEncode({
                        'nombre': nombreController.text,
                        'telefono': telefonoController.text,
                      }),
                    );

                    if (response.statusCode == 200) {
                      if (mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                              content:
                                  Text('Usuario actualizado correctamente')),
                        );
                      }
                      setState(() {
                        _futureUsers = fetchUsers();
                        _selectedUser = null;
                      });
                    } else {
                      throw Exception('Error al actualizar el usuario');
                    }
                  } catch (e) {
                    if (mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Error: ${e.toString()}')),
                      );
                    }
                  }
                },
                child: const Text('Guardar'),
              ),
              ElevatedButton(
                onPressed: _cancelEdit,
                style: ElevatedButton.styleFrom(backgroundColor: Colors.grey),
                child: const Text('Cancelar'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
