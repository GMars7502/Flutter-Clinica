import 'package:flutter/widgets.dart';

class CreadoAlgo extends StatelessWidget {
  const CreadoAlgo({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
