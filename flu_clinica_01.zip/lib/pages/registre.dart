import 'dart:convert';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart'; // Asegúrate de importar intl para formatear la fecha
import 'package:flu_clinica_01/address/ipaddress.dart';

import 'package:flu_clinica_01/pages/Login.dart'; // Asegúrate de importar Login.dart correctamente

class RegistroPage extends StatefulWidget {
  static const String routename = 'registro';

  const RegistroPage({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _RegistroPageState createState() => _RegistroPageState();
}

class _RegistroPageState extends State<RegistroPage>
    with SingleTickerProviderStateMixin {
  late TextEditingController nombreController;
  late TextEditingController correoController;
  late TextEditingController contrasenaController;
  late TextEditingController fechaNacimientoController;
  late String selectedRol;
  late String selectedGenero;
  late TextEditingController telefonoController;

  @override
  void initState() {
    super.initState();
    nombreController = TextEditingController();
    correoController = TextEditingController();
    contrasenaController = TextEditingController();
    fechaNacimientoController = TextEditingController();
    selectedRol = 'paciente';
    selectedGenero = 'masculino';
    telefonoController = TextEditingController();
  }

  Future<void> _registrarUsuario() async {
    String nombre = nombreController.text;
    String correo = correoController.text;
    String contrasena = contrasenaController.text;
    String fechaNacimiento = fechaNacimientoController.text;
    String telefono = telefonoController.text;
    //http://matasanos.c1.is/api/usuarios
    //String apiUrl = 'http://matasanos.c1.is/api/usuarios';

    if (nombre.length < 2) {
      showSnackBar(context, 'El nombre debe tener al menos 2 caracteres');
      return;
    }
    if (contrasena.length < 6) {
      showSnackBar(context, 'La contraseña debe tener al menos 8 caracteres');
      return;
    }
    if (telefono.length < 10) {
      showSnackBar(
          context, 'El número de teléfono debe tener al menos 9 caracteres');
      return;
    }
    if (correo.isEmpty || contrasena.isEmpty || telefono.isEmpty) {
      showSnackBar(context, 'Debe llenar todos los campos');
      return;
    }

    try {
      UserCredential userCredential =
          await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: correo,
        password: contrasena,
      );
      User? user = userCredential.user;
      print('Usuario registrado: ${user!.uid}');

      String idgoogle = user.uid;

      Map<String, String> body = {
        'nombre': nombre,
        'correo': correo,
        'contraseña': contrasena,
        'rol': selectedRol,
        'id_google': idgoogle,
        'fecha_nacimiento': fechaNacimiento,
        'genero': selectedGenero,
        'telefono': telefono,
      };

      print('Datos enviados: $body');
      //http://192.168.27.178:8000/api
      //String domain = 'matasanos.c1.is';
      IpAddress direccion = IpAddress();
      String domain = direccion.domain;
      String path = '/api/usuarios';

      //String apiUrl = 'http://169.254.140.204:8000/api/usuarios';
      var response = await http.post(
        Uri.http(domain, path),
        body: jsonEncode(body),
        headers: {'Content-Type': 'application/json'},
      );
      if (response.isRedirect) {
        print('Redireccionando a: ${response.body}');
      }

      if (response.statusCode > 200 && response.statusCode < 300) {
        print('Usuario registrado correctamente');
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Usuario registrado correctamente')),
          );
        }
        // Aquí podrías manejar la navegación a otra pantalla
        Navigator.pushReplacementNamed(context, LoginPage.routename);
      } else {
        print('Error al registrar usuario: ${response.statusCode}');
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
                content: Text(
                    'Error al  registro de usuario: ${response.statusCode}')),
          );
        }
      }
    } on FirebaseAuthException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text('Error al  registro de usuario: ${e.message}')),
        );
      }
      print('Error en la creación de usuario: ${e.message}');
      return;
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error al  registro de usuario: $e')),
        );
      }
      print('Error en la solicitud HTTP: $e');
    }
  }

  void _cancelarRegistro() {
    Navigator.pushReplacementNamed(
      context,
      LoginPage.routename,
    ); // Regresar a la pantalla anterior (en este caso, Login)
  }

  Future<void> _selectFechaNacimiento(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (picked != null) {
      setState(() {
        fechaNacimientoController.text =
            DateFormat('yyyy-MM-dd').format(picked);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Registro de Usuario'),
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            icon: const Icon(Icons.cancel),
            onPressed: _cancelarRegistro,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                controller: nombreController,
                decoration: const InputDecoration(
                  labelText: 'Nombre',
                ),
              ),
              const SizedBox(height: 12.0),
              TextFormField(
                controller: correoController,
                decoration: const InputDecoration(
                  labelText: 'Correo',
                ),
              ),
              const SizedBox(height: 12.0),
              TextFormField(
                controller: contrasenaController,
                decoration: const InputDecoration(
                  labelText: 'Contraseña',
                ),
                obscureText: true,
              ),
              const SizedBox(height: 12.0),
              TextFormField(
                controller: fechaNacimientoController,
                decoration: InputDecoration(
                  labelText: 'Fecha de Nacimiento',
                  suffixIcon: IconButton(
                    icon: const Icon(Icons.calendar_today),
                    onPressed: () => _selectFechaNacimiento(context),
                  ),
                ),
                readOnly: true,
              ),
              const SizedBox(height: 12.0),
              DropdownButtonFormField<String>(
                value: selectedRol,
                decoration: const InputDecoration(
                  labelText: 'Rol',
                ),
                items: ['paciente', 'medico', 'admin'].map((String rol) {
                  return DropdownMenuItem<String>(
                    value: rol,
                    child: Text(rol),
                  );
                }).toList(),
                onChanged: (String? value) {
                  if (value != null) {
                    setState(() {
                      selectedRol = value;
                    });
                  }
                },
              ),
              const SizedBox(height: 12.0),
              DropdownButtonFormField<String>(
                value: selectedGenero,
                decoration: const InputDecoration(
                  labelText: 'Género',
                ),
                items: ['masculino', 'femenino', 'otro'].map((String genero) {
                  return DropdownMenuItem<String>(
                    value: genero,
                    child: Text(genero),
                  );
                }).toList(),
                onChanged: (String? value) {
                  if (value != null) {
                    setState(() {
                      selectedGenero = value;
                    });
                  }
                },
              ),
              const SizedBox(height: 12.0),
              TextFormField(
                controller: telefonoController,
                decoration: const InputDecoration(
                  labelText: 'Teléfono',
                ),
                keyboardType: TextInputType.phone,
              ),
              const SizedBox(height: 20.0),
              ElevatedButton(
                onPressed: _registrarUsuario,
                child: const Text('Registrar'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void showSnackBar(BuildContext context, String s) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(s)),
    );
  }
}
