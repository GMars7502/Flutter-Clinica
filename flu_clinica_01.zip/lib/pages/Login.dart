// ignore_for_file: file_names, unnecessary_import

import 'dart:convert';
import 'package:flu_clinica_01/pages/page_admin.dart';
import 'package:flu_clinica_01/pages/page_medico.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_signin_button/flutter_signin_button.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flu_clinica_01/Session/providerSession.dart'; // Asegúrate de que la ruta sea correcta
import 'package:flu_clinica_01/Session/data.dart'; // Asegúrate de que la ruta sea correcta
import 'package:flu_clinica_01/services/auth_correo.dart';
import 'package:flu_clinica_01/pages/Home_page.dart'; // Asegúrate de que la ruta sea correcta
import 'registre.dart';
import 'package:http/http.dart' as http;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flu_clinica_01/services/auth_google.dart';
import 'package:flu_clinica_01/address/ipaddress.dart';

// Importa las bibliotecas necesarias

class LoginPage extends StatelessWidget {
  static const String routename = 'login';

  const LoginPage({super.key});

  @override
  Widget build(BuildContext context) {
    TextEditingController emailController = TextEditingController();
    TextEditingController passwordController = TextEditingController();

    return Scaffold(
      backgroundColor: const Color.fromRGBO(242, 238, 228, 1),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset('assets/logo.jpeg'),
              const SizedBox(height: 20.0),
              TextField(
                controller: emailController,
                decoration: const InputDecoration(
                  labelText: 'Correo',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 20.0),
              TextField(
                controller: passwordController,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'Contraseña',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 20.0),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color.fromRGBO(88, 113, 179, 1),
                  padding: const EdgeInsets.symmetric(vertical: 15.0),
                  minimumSize: const Size(double.infinity, 0),
                ),
                onPressed: () async {
                  try {
                    final authService = FirebaseAuthService();
                    IpAddress direccion = IpAddress();
                    String domain = direccion.domain;

                    final user = await authService.signInWithEmailAndPassword(
                      emailController.text.trim(),
                      passwordController.text,
                    );

                    if (user != null) {
                      //String apiUrl =
                      //  'http://192.168.27.54:8000/api/usuarios/login';
                      String path0 = '/api/usuarios/login';
                      Map<String, String> requestBody = {
                        'correo': emailController.text.trim()
                      };
                      print('object');
                      var response = await http.post(
                        Uri.http(domain, path0),
                        body: jsonEncode(requestBody),
                        headers: {'Content-Type': 'application/json'},
                      );
                      print('hhhhhhh');

                      final data = jsonDecode(response.body);
                      String thisname = data['nombre'];
                      String trol = data['rol'];
                      String idUsuario = data['id'].toString();
                      String? genero = data['genero'];
                      String? telefono = data['telefono'];
                      String? fotoPerfil = data['foto_perfil'];
                      String? createdat = data['created_at'];
                      String? updatedat = data['updated_at'];
                      String? fechaNacimientoStr = data['fecha_nacimiento'];

                      // Convertir fecha de nacimiento de String a DateTime
                      DateTime? fechaNacimiento;
                      if (fechaNacimientoStr != null) {
                        fechaNacimiento = DateTime.parse(fechaNacimientoStr);
                      }

                      print('uuuuuu');
                      if (context.mounted) {
                        Provider.of<UserProvider>(context, listen: false)
                            .setUser(
                          UserData(
                            role: trol,
                            idGoogle: user.uid,
                            birthDate: fechaNacimiento,
                            gender: genero,
                            phoneNumber: telefono,
                            photoUrl: fotoPerfil,
                            createdAt: createdat,
                            updatedAt: updatedat,
                            id: idUsuario,
                            email: user.email ?? '',
                            name: thisname,
                          ),
                        );
                      }
                      if (context.mounted) {
                        if (trol == "paciente") {
                          Navigator.pushReplacementNamed(
                              context, HomePage.routename);
                        } else if (trol == "medico") {
                          Navigator.pushReplacementNamed(
                              context, PagMedico.routename);

                          // Implementación para médicos si es necesario
                        } else if (trol == "admin") {
                          Navigator.pushReplacementNamed(
                              context, HomeAdmin.routename);
                          // Implementación para administradores si es necesario
                        }
                      }
                    } else {
                      throw Exception('Error de inicio de sesión');
                    }
                  } catch (e) {
                    print(e);
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(
                              'Error de inicio de sesión: ${e.toString()}'),
                        ),
                      );
                    }
                  }
                },
                child: const Text('Iniciar sesión'),
              ),
              const SizedBox(height: 20.0),
              SignInButton(
                Buttons.Google,
                onPressed: () async {
                  try {
                    IpAddress direccion = IpAddress();
                    String domain = direccion.domain;
                    final user = await AuthGoogle().loginGoogle();

                    if (user != null) {
                      String? Gcorreo = user.email;
                      String? Gnombre = user.displayName;
                      String path1 = '/api/usuarios/login';
                      //String apiUrl =
                      //  'http://169.254.140.204:8000/api/usuarios/login';
                      Map<String, String> requestBody = {
                        'correo': Gcorreo ?? ''
                      };

                      var response = await http.post(
                        Uri.http(domain, path1),
                        body: jsonEncode(requestBody),
                        headers: {'Content-Type': 'application/json'},
                      );

                      print(response.body);
                      print(response.statusCode);
                      print(response.isRedirect);

                      final data = jsonDecode(response.body);
                      String thisname = data['correo'] ?? 'Nope';

                      if (thisname == 'Nope') {
                        // Registro del usuario si no existe en la base de datos
                        //String otraUrl = 'http://matasanos.c1.is/api/usuarios/';
                        String idgoogle = user.uid;
                        print("instancias de datos");

                        Map<String, String> body = {
                          'nombre': Gnombre ?? '',
                          'correo': Gcorreo ?? '',
                          'contraseña': idgoogle,
                          'rol': 'paciente',
                          'id_google': idgoogle,
                          'genero': 'otro',
                          'telefono': user.phoneNumber ?? '123',
                        };
                        print('armando del body');
                        print(body);

                        //String domain = 'matasanos.c1.is';
                        //String path = '/api/usuarios';
                        String path2 = '/api/usuarios';
                        //String Urlst =
                        //  'http://169.254.140.204:8000/api/usuarios';

                        var tresponse = await http.post(
                          Uri.http(domain, path2),
                          body: jsonEncode(body),
                          headers: {'Content-Type': 'application/json'},
                        );

                        if (tresponse.isRedirect) {
                          print(
                              'el valor de response es: ${tresponse.isRedirect}');
                          print('el valor de response es: ${tresponse.body}');
                        }

                        if (tresponse.statusCode > 200 &&
                            tresponse.statusCode < 300) {
                          final tdata = jsonDecode(tresponse.body);
                          String thisname = Gnombre ?? '';
                          String trol = tdata['rol'] ?? '';
                          String idUsuario = tdata['id'].toString();
                          String genero = tdata['genero'] ?? 'masculino';
                          String correot = Gcorreo ?? '';
                          if (context.mounted) {
                            Provider.of<UserProvider>(context, listen: false)
                                .setUser(
                              UserData(
                                role: trol,
                                idGoogle: user.uid,
                                gender: genero,
                                id: idUsuario,
                                email: correot,
                                name: thisname,
                              ),
                            );

                            Navigator.pushReplacementNamed(
                                context, HomePage.routename);
                          }
                        } else {
                          print(
                              'el valor de response es: ${tresponse.isRedirect}');
                          print('el valor de response es: ${tresponse.body}');
                          print(
                              'Error al registrar usuario: ${tresponse.statusCode}');
                          if (context.mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(
                                    'Error al registrar usuario: ${tresponse.statusCode}'),
                              ),
                            );
                          }
                        }
                      } else {
                        // Usuario existe en la base de datos
                        String thisname = data['nombre'];
                        String trol = data['rol'];
                        String idUsuario = data['id'].toString();
                        String? genero = data['genero'];
                        String? telefono = data['telefono'];
                        String? fotoPerfil = data['foto_perfil'];
                        String? createdat = data['created_at'];
                        String? updatedat = data['updated_at'];
                        String? fechaNacimientoStr = data['fecha_nacimiento'];

                        // Convertir fecha de nacimiento de String a DateTime
                        DateTime? fechaNacimiento;
                        if (fechaNacimientoStr != null) {
                          fechaNacimiento = DateTime.parse(fechaNacimientoStr);
                        }
                        if (context.mounted) {
                          Provider.of<UserProvider>(context, listen: false)
                              .setUser(
                            UserData(
                              role: trol,
                              idGoogle: user.uid,
                              birthDate: fechaNacimiento,
                              gender: genero,
                              phoneNumber: telefono,
                              photoUrl: fotoPerfil,
                              createdAt: createdat,
                              updatedAt: updatedat,
                              id: idUsuario,
                              email: user.email ?? '',
                              name: thisname,
                            ),
                          );
                        }
                        if (context.mounted) {
                          if (trol == "paciente") {
                            Navigator.pushReplacementNamed(
                                context, HomePage.routename);
                          } else if (trol == "admin") {
                            Navigator.pushReplacementNamed(
                                context, HomeAdmin.routename);
                          } else if (trol == "medico") {
                            Navigator.pushReplacementNamed(
                                context, PagMedico.routename);
                          }
                        }
                      }
                    } else {
                      throw Exception('Error al iniciar sesión con Google');
                    }
                  } on FirebaseAuthException catch (error) {
                    print(error.message);
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(error.message ?? 'Algo salió mal'),
                        ),
                      );
                    }
                  } catch (e) {
                    print(e);
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text(e.toString()),
                        ),
                      );
                    }
                  }
                },
              ),
              const SizedBox(height: 10.0),
              TextButton(
                onPressed: () {
                  Navigator.popAndPushNamed(context, RegistroPage.routename);
                },
                child: const Text('Registrarse'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
