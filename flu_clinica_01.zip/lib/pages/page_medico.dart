import 'package:flu_clinica_01/pages/Login.dart';
import 'package:flu_clinica_01/pages/class/perfil.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flu_clinica_01/Session/providerSession.dart';
import 'package:flu_clinica_01/pages/class/classmedico/pacientes.dart';
import 'package:flu_clinica_01/pages/class/classmedico/citascompletadas.dart';
import 'package:flu_clinica_01/pages/class/classmedico/citascanceladas.dart';

class PagMedico extends StatefulWidget {
  static const String routename = 'pagMedico';

  const PagMedico({super.key});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<PagMedico> {
  int _selectedIndex = 0;

  static final List<Widget> _widgetOptions = <Widget>[
    const UserInfoPage(),
    const CitasProgramadasPage(title: 'CitasProg'),
    const CitasCompletadasPage(title: 'CitasComp'),
    const CitasCanceladasPage(title: 'CitasCancep'),
    const pagPerfil(title: 'Perfil'),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  void _logout(BuildContext context) {
    Provider.of<UserProvider>(context, listen: false)
        .clearUser(); // Limpiar datos de usuario
    Navigator.pushNamedAndRemoveUntil(context, LoginPage.routename,
        (route) => false); // Navegar a la página de inicio de sesión
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Home'),
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () =>
                _logout(context), // Llamar al método de cierre de sesión
          ),
        ],
      ),
      body: Center(
        child: _widgetOptions.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_today),
            label: 'CitasProg',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_today),
            label: 'CitasComp',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_today),
            label: 'CitasCancep',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.assignment),
            label: 'Perfil',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.amber[800],
        unselectedItemColor: Colors.grey,
        onTap: _onItemTapped,
      ),
    );
  }
}

class UserInfoPage extends StatelessWidget {
  const UserInfoPage({super.key});

  @override
  Widget build(BuildContext context) {
    final userProvider = Provider.of<UserProvider>(context);
    final user = userProvider.userData;

    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset('assets/logo.jpeg'),
          const SizedBox(height: 20),
          const Text(
            'Bienvenido,',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          Text(
            user?.name ?? 'Usuario no identificado',
            style: const TextStyle(fontSize: 18),
          ),
        ],
      ),
    );
  }
}

class BlankPage extends StatelessWidget {
  final String title;

  const BlankPage({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        title,
        style: const TextStyle(fontSize: 24),
      ),
    );
  }
}

/*
class AllUsuarios extends StatelessWidget {
  final String title;

  const AllUsuarios({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        title,
        style: const TextStyle(fontSize: 24),
      ),
    );
  }
}
*/













